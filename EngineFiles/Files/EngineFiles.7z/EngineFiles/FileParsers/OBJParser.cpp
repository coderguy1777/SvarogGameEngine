#include "OBJParser.h"
#include "Files/GameEngineHeader.h"
using namespace std;

void ObjFileParser::objparser(string fname, vector<double>xyzcoordinates) {
    
}