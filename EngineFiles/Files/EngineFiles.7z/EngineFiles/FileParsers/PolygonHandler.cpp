#include "GameEngineHeader.h"
#include "PolygonHandler.h"

void PolygonInputter::polygondefintion() {
    
}

double PolygonInputter::polygoncoordinates(double x, double y, double z) {
    return x;
}

