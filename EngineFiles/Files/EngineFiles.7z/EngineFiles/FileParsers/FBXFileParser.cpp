#include "GameEngineHeader.h"
#include "FBXFileParser.h"
using namespace std;

void FBXFileParser::fbxparser(string fname, vector<double>xyzcoords) {
    
}